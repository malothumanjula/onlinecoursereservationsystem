"""
CourseHub – Online Course Registration Backend
Flask REST API with SQLite persistence
Run: python app.py
API: http://localhost:5000
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3, uuid, re, os
from datetime import datetime

app = Flask(__name__)
CORS(app)  # Allow frontend (index.html) to call the API

DB_PATH = "coursehub.db"

# ─────────────────────────────────────────────
# Course catalogue (mirrors frontend data)
# ─────────────────────────────────────────────
COURSES = {
    1:  {"title": "Data Structures & Algorithms",   "credits": 4, "seats": 60, "fee": 4800},
    2:  {"title": "Machine Learning Fundamentals",  "credits": 4, "seats": 45, "fee": 5500},
    3:  {"title": "Database Management Systems",    "credits": 3, "seats": 70, "fee": 3800},
    4:  {"title": "React & Modern Web Dev",         "credits": 3, "seats": 50, "fee": 3500},
    5:  {"title": "Data Analysis with Python",      "credits": 3, "seats": 55, "fee": 4200},
    6:  {"title": "Discrete Mathematics",           "credits": 4, "seats": 80, "fee": 3200},
    7:  {"title": "Computer Networks",              "credits": 3, "seats": 60, "fee": 3800},
    8:  {"title": "Deep Learning & Neural Nets",    "credits": 4, "seats": 40, "fee": 6000},
    9:  {"title": "Full-Stack Web Development",     "credits": 4, "seats": 50, "fee": 4500},
    10: {"title": "Statistical Methods",            "credits": 3, "seats": 65, "fee": 3000},
    11: {"title": "Big Data Engineering",           "credits": 4, "seats": 45, "fee": 5200},
    12: {"title": "Operating Systems",              "credits": 4, "seats": 75, "fee": 4000},
}

# ─────────────────────────────────────────────
# Database setup
# ─────────────────────────────────────────────
def get_db():
    """Return a new DB connection with row_factory set."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Create tables if they don't exist."""
    conn = get_db()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id  TEXT NOT NULL UNIQUE,
            name        TEXT NOT NULL,
            email       TEXT NOT NULL,
            phone       TEXT,
            department  TEXT,
            year        TEXT,
            created_at  TEXT NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS registrations (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            registration_id TEXT NOT NULL UNIQUE,
            student_id      TEXT NOT NULL,
            created_at      TEXT NOT NULL
        )
    """)

    cur.execute("""
        CREATE TABLE IF NOT EXISTS registration_courses (
            id              INTEGER PRIMARY KEY AUTOINCREMENT,
            registration_id TEXT NOT NULL,
            course_id       INTEGER NOT NULL,
            course_title    TEXT NOT NULL,
            credits         INTEGER NOT NULL,
            fee             INTEGER NOT NULL
        )
    """)

    conn.commit()
    conn.close()
    print("✅  Database initialised:", DB_PATH)


# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────
def validate_email(email: str) -> bool:
    return bool(re.match(r"^[^\s@]+@[^\s@]+\.[^\s@]+$", email))


def validate_payload(data: dict) -> list[str]:
    """Return a list of validation error messages (empty = valid)."""
    errors = []
    if not data.get("name", "").strip():
        errors.append("Name is required.")
    if not validate_email(data.get("email", "")):
        errors.append("A valid email address is required.")
    if not data.get("student_id", "").strip():
        errors.append("Student ID is required.")
    if not data.get("department"):
        errors.append("Department is required.")
    course_ids = data.get("course_ids", [])
    if not course_ids:
        errors.append("Select at least one course.")
    if len(course_ids) > 6:
        errors.append("You cannot register for more than 6 courses per semester.")
    invalid = [cid for cid in course_ids if cid not in COURSES]
    if invalid:
        errors.append(f"Unknown course IDs: {invalid}")
    return errors


# ─────────────────────────────────────────────
# Routes
# ─────────────────────────────────────────────
@app.route("/")
def index():
    return jsonify({"message": "CourseHub API is running 🎓", "version": "1.0"})


# ── GET /api/courses ──────────────────────────
@app.route("/api/courses", methods=["GET"])
def get_courses():
    """Return all courses with live seat availability."""
    conn = get_db()
    cur = conn.cursor()

    enriched = []
    for cid, c in COURSES.items():
        # Count how many students have registered for this course
        cur.execute(
            "SELECT COUNT(*) AS cnt FROM registration_courses WHERE course_id = ?",
            (cid,)
        )
        enrolled = cur.fetchone()["cnt"]
        enriched.append({
            "id":        cid,
            "title":     c["title"],
            "credits":   c["credits"],
            "seats":     c["seats"],
            "enrolled":  enrolled,
            "available": max(0, c["seats"] - enrolled),
            "fee":       c["fee"],
        })

    conn.close()
    return jsonify({"courses": enriched, "total": len(enriched)})


# ── POST /api/register ────────────────────────
@app.route("/api/register", methods=["POST"])
def register():
    """
    Register a student for one or more courses.

    Expected JSON body:
    {
        "name":       "Arjun Sharma",
        "email":      "arjun@college.edu",
        "student_id": "CS22B1001",
        "phone":      "+91 9876543210",   (optional)
        "department": "Computer Science",
        "year":       "2nd Year",
        "course_ids": [1, 3, 6]
    }
    """
    data = request.get_json(force=True, silent=True)
    if not data:
        return jsonify({"error": "Invalid JSON body."}), 400

    errors = validate_payload(data)
    if errors:
        return jsonify({"error": " | ".join(errors)}), 422

    conn = get_db()
    cur = conn.cursor()

    try:
        now = datetime.utcnow().isoformat()
        sid = data["student_id"].strip().upper()

        # Upsert student record
        cur.execute("SELECT id FROM students WHERE student_id = ?", (sid,))
        if cur.fetchone():
            cur.execute("""
                UPDATE students
                SET name=?, email=?, phone=?, department=?, year=?
                WHERE student_id=?
            """, (
                data["name"].strip(),
                data["email"].strip().lower(),
                data.get("phone", ""),
                data["department"],
                data.get("year", ""),
                sid
            ))
        else:
            cur.execute("""
                INSERT INTO students (student_id, name, email, phone, department, year, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                sid,
                data["name"].strip(),
                data["email"].strip().lower(),
                data.get("phone", ""),
                data["department"],
                data.get("year", ""),
                now
            ))

        # Check seat availability for all requested courses
        course_ids = list(set(int(cid) for cid in data["course_ids"]))
        for cid in course_ids:
            c = COURSES[cid]
            cur.execute(
                "SELECT COUNT(*) AS cnt FROM registration_courses WHERE course_id = ?",
                (cid,)
            )
            enrolled = cur.fetchone()["cnt"]
            if enrolled >= c["seats"]:
                conn.rollback()
                conn.close()
                return jsonify({
                    "error": f'No seats available for "{c["title"]}".'
                }), 409

        # Create registration record
        reg_id = "REG-" + uuid.uuid4().hex[:8].upper()
        cur.execute("""
            INSERT INTO registrations (registration_id, student_id, created_at)
            VALUES (?, ?, ?)
        """, (reg_id, sid, now))

        # Insert each course into registration_courses
        total_credits = 0
        total_fee = 0
        registered_courses = []
        for cid in course_ids:
            c = COURSES[cid]
            cur.execute("""
                INSERT INTO registration_courses
                    (registration_id, course_id, course_title, credits, fee)
                VALUES (?, ?, ?, ?, ?)
            """, (reg_id, cid, c["title"], c["credits"], c["fee"]))
            total_credits += c["credits"]
            total_fee += c["fee"]
            registered_courses.append({
                "id":      cid,
                "title":   c["title"],
                "credits": c["credits"],
                "fee":     c["fee"],
            })

        conn.commit()
        return jsonify({
            "message":         "Registration successful!",
            "registration_id": reg_id,
            "student_id":      sid,
            "student_name":    data["name"].strip(),
            "courses":         registered_courses,
            "total_credits":   total_credits,
            "total_fee":       total_fee,
            "registered_at":   now,
        }), 201

    except sqlite3.IntegrityError as e:
        conn.rollback()
        return jsonify({"error": f"Database constraint error: {e}"}), 409
    except Exception as e:
        conn.rollback()
        return jsonify({"error": f"Internal server error: {e}"}), 500
    finally:
        conn.close()


# ── GET /api/student/<student_id> ─────────────
@app.route("/api/student/<student_id>", methods=["GET"])
def get_student(student_id):
    """Fetch a student's full registration history."""
    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT * FROM students WHERE student_id = ?", (student_id.upper(),))
    student = cur.fetchone()
    if not student:
        conn.close()
        return jsonify({"error": "Student not found."}), 404

    cur.execute("""
        SELECT r.registration_id, r.created_at,
               rc.course_id, rc.course_title, rc.credits, rc.fee
        FROM registrations r
        JOIN registration_courses rc ON r.registration_id = rc.registration_id
        WHERE r.student_id = ?
        ORDER BY r.created_at DESC
    """, (student_id.upper(),))

    rows = cur.fetchall()
    conn.close()

    # Group by registration
    regs = {}
    for row in rows:
        rid = row["registration_id"]
        if rid not in regs:
            regs[rid] = {"registration_id": rid, "registered_at": row["created_at"], "courses": []}
        regs[rid]["courses"].append({
            "id":      row["course_id"],
            "title":   row["course_title"],
            "credits": row["credits"],
            "fee":     row["fee"],
        })

    return jsonify({
        "student": {
            "student_id":  student["student_id"],
            "name":        student["name"],
            "email":       student["email"],
            "phone":       student["phone"],
            "department":  student["department"],
            "year":        student["year"],
        },
        "registrations": list(regs.values()),
    })


# ── GET /api/registrations ────────────────────
@app.route("/api/registrations", methods=["GET"])
def list_registrations():
    """Admin endpoint: list all registrations (paginated)."""
    page  = int(request.args.get("page",  1))
    limit = int(request.args.get("limit", 20))
    offset = (page - 1) * limit

    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) AS total FROM registrations")
    total = cur.fetchone()["total"]

    cur.execute("""
        SELECT r.registration_id, r.student_id, r.created_at,
               s.name, s.email, s.department
        FROM registrations r
        JOIN students s ON r.student_id = s.student_id
        ORDER BY r.created_at DESC
        LIMIT ? OFFSET ?
    """, (limit, offset))

    rows = cur.fetchall()
    conn.close()

    return jsonify({
        "total": total,
        "page":  page,
        "limit": limit,
        "registrations": [dict(r) for r in rows],
    })


# ── DELETE /api/registration/<reg_id> ─────────
@app.route("/api/registration/<reg_id>", methods=["DELETE"])
def cancel_registration(reg_id):
    """Cancel a registration and free the seats."""
    conn = get_db()
    cur = conn.cursor()

    cur.execute("SELECT id FROM registrations WHERE registration_id = ?", (reg_id,))
    if not cur.fetchone():
        conn.close()
        return jsonify({"error": "Registration not found."}), 404

    try:
        cur.execute("DELETE FROM registration_courses WHERE registration_id = ?", (reg_id,))
        cur.execute("DELETE FROM registrations WHERE registration_id = ?", (reg_id,))
        conn.commit()
        return jsonify({"message": f"Registration {reg_id} cancelled successfully."})
    except Exception as e:
        conn.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        conn.close()


# ─────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────
if __name__ == "__main__":
    init_db()
    print("🚀  CourseHub API  →  http://localhost:5000")
    print("📋  Endpoints:")
    print("    GET    /api/courses")
    print("    POST   /api/register")
    print("    GET    /api/student/<student_id>")
    print("    GET    /api/registrations")
    print("    DELETE /api/registration/<reg_id>")
    app.run(debug=True, host="0.0.0.0", port=5000)
